import { products as seedProducts, features as seedFeatures, templates as seedTemplates, customers as seedCustomers, releases, tasks, logs as seedLogs, nav, statusMeta } from "./data.js";

const state = {
  page: "dashboard",
  query: "",
  filter: "全部",
  products: structuredClone(seedProducts),
  features: structuredClone(seedFeatures),
  templates: structuredClone(seedTemplates),
  customers: structuredClone(seedCustomers),
  logs: structuredClone(seedLogs),
  modal: null,
  drawer: null,
  toast: ""
};

const root = document.querySelector("#root");
const iconMap = {
  dashboard: "▦", products: "▣", features: "◇", templates: "▤", releases: "↗", customers: "▥",
  entitlements: "◇", expiring: "◷", trials: "✦", suspended: "⊘", usage: "▨", notifications: "◌",
  logs: "≡", accounts: "◎", roles: "◇", settings: "⚙"
};

function render() {
  const title = nav.flatMap(group => group[1]).find(item => item[1] === state.page)?.[0] || "營運儀表板";
  root.innerHTML = `
    <div class="app">
      ${sidebar()}
      <main>
        <header class="topbar">
          <div><p class="eyebrow">DS 總控台</p><h1>${title}</h1></div>
          <div class="topActions">
            <div class="search"><span>⌕</span><input id="globalSearch" value="${escapeAttr(state.query)}" placeholder="搜尋產品、客戶、功能或版型"></div>
            <button class="iconBtn" data-action="toast" data-message="目前有 6 件待處理事項">◌</button>
            <button class="primary" data-action="create">＋ 新增</button>
          </div>
        </header>
        ${page()}
      </main>
      ${modal()}
      ${drawer()}
      ${state.toast ? `<div class="toast">✓ ${state.toast}</div>` : ""}
    </div>`;
}

function sidebar() {
  return `<aside class="sidebar">
    <div class="brand"><div class="mark">DS</div><div><b>DS總控台</b><span>產品與客戶管理</span></div></div>
    <nav>${nav.map(([group, items]) => `<div class="navGroup"><p>${group}</p>${items.map(([label, key]) => `<button class="${state.page === key ? "active" : ""}" data-page="${key}"><span>${iconMap[key] || "·"}</span><span>${label}</span></button>`).join("")}</div>`).join("")}</nav>
    <div class="profile"><div class="avatar">王</div><div><b>王小明</b><span>系統管理員</span></div></div>
  </aside>`;
}

function page() {
  if (state.page === "dashboard") return dashboard();
  if (state.page === "products") return productsPage();
  if (state.page === "features") return featuresPage();
  if (state.page === "templates") return templatesPage();
  if (state.page === "releases") return releasesPage();
  if (["customers", "entitlements", "expiring", "trials", "suspended"].includes(state.page)) return customersPage();
  if (state.page === "usage") return usagePage();
  if (state.page === "notifications") return notificationsPage();
  if (state.page === "logs") return logsPage(state.logs);
  return systemPage();
}

function dashboard() {
  const soon = state.customers.filter(c => c.daysLeft <= 30 && c.daysLeft >= 0).length;
  const stats = [
    ["產品總數", state.products.length, "▣"], ["已上線產品", state.products.filter(p => p.status === "已上線").length, "↗"],
    ["維護中功能", state.features.filter(f => f.status === "維護中").length, "◇"], ["客戶公司數", state.customers.length, "▥"],
    ["使用中的產品權限", 214, "◆"], ["30 天內即將到期客戶", soon, "◷"],
    ["試用中客戶", state.customers.filter(c => c.status === "試用中").length, "✦"], ["額度即將用完客戶", state.customers.filter(c => parseInt(c.quota) > 80).length, "▨"]
  ];
  return `<div class="stack">
    <section class="stats">${stats.map(s => `<div class="stat"><span class="statIcon">${s[2]}</span><span>${s[0]}</span><b>${s[1]}</b></div>`).join("")}</section>
    <div class="grid two">
      ${panel("產品運行狀態", state.products.map(p => `<div class="productRun"><div class="productIcon">${p.icon}</div><div><b>${p.name}</b><span>${p.version} · ${p.customers} 間客戶</span></div>${badge(p.status)}${toggle(p.enabled, "toggleProduct", p.id)}</div>`).join(""), "管理產品")}
      ${panel("待處理事項", tasks.map(t => `<div class="task">${badge(t.priority === "高" ? "維護中" : "即將到期")}<div><b>${t.title}</b><span>${t.desc}</span></div><button class="textBtn" data-action="toast" data-message="已開啟處理流程">${"處理"}</button></div>`).join(""), "查看全部")}
    </div>
    <div class="grid two">
      ${table("即將到期客戶", ["客戶公司", "產品", "到期日", "剩餘天數", "客戶狀態", "內部負責人", "操作"], state.customers.filter(c => c.daysLeft <= 30).map(c => [c.name, c.products, c.expiresAt, `${c.daysLeft} 天`, badge(c.status), c.owner, rowActions("customer", c.id, true)]))}
      ${table("最近發布紀錄", ["產品", "版本", "發布項目", "發布範圍", "發布時間", "發布人員"], releases.map(r => [r.product, r.version, r.item, r.scope, r.time, r.user]))}
    </div>
    ${logsPage(state.logs.slice(0, 4), "最近操作紀錄")}
  </div>`;
}

function productsPage() {
  const rows = filtered(state.products).map(p => [productName(p), p.code, p.desc, p.version, badge(p.status), p.featureCount, p.customers, p.updatedAt, toggle(p.enabled, "toggleProduct", p.id), rowActions("product", p.id)]);
  return `<div class="stack">${tabs(["全部", "已上線", "維護中", "停止服務", "已下架"])}${table("產品列表", ["產品名稱", "產品代碼", "產品說明", "目前版本", "產品狀態", "功能數量", "使用客戶數", "最近更新時間", "產品總開關", "操作"], rows)}${productDetail()}</div>`;
}

function featuresPage() {
  const rows = filtered(state.features).map(f => [f.name, f.code, f.product, f.version, badge(f.status), f.scope, f.customers, toggle(f.enabled, "toggleFeature", f.id), f.updatedAt, rowActions("feature", f.id)]);
  return `<div class="stack">${tabs(["全部", "E2B", "官網方案", "已釋出", "維護中", "指定客戶測試"])}${table("功能管理", ["功能名稱", "功能代碼", "所屬產品", "功能版本", "功能狀態", "開放範圍", "開放客戶數", "功能總開關", "最近更新時間", "操作"], rows)}</div>`;
}

function templatesPage() {
  const rows = filtered(state.templates).map(t => [t.name, t.code, t.version, badge(t.status), t.type, t.check, t.customers, t.updatedAt, rowActions("template", t.id)]);
  return `<div class="stack">${tabs(["全部", "已上線", "等待開通", "檢查失敗"])}
    <div class="uploadBox"><div><span class="uploadGlyph">⇧</span><b>上傳 HTML 版型 ZIP</b><span>需包含 index.html、css/、js/、images/、assets/，上傳後自動檢查結構、外部 Script 與版型規則。</span></div><button class="primary" data-action="toast" data-message="已建立模擬上傳任務，等待檢查">選擇 ZIP</button></div>
    ${table("官網版型列表", ["版型名稱", "代碼", "版本", "狀態", "類型", "檢查結果", "使用客戶", "更新時間", "操作"], rows)}
  </div>`;
}

function releasesPage() {
  return `<div class="grid two">
    ${table("版本與發布", ["產品", "版本", "發布項目", "發布範圍", "發布時間", "發布人員"], releases.map(r => [r.product, r.version, r.item, r.scope, r.time, r.user]))}
    ${panel("發布檢查清單", ["功能測試通過", "指定客戶測試確認", "異動紀錄已建立", "通知內容已確認", "可回復版本已標記"].map((x, i) => `<label class="check"><input type="checkbox" ${i < 3 ? "checked" : ""}>${x}</label>`).join("") + `<button class="primary wide" data-action="toast" data-message="已建立模擬發布紀錄">建立模擬發布</button>`)}
  </div>`;
}

function customersPage() {
  let rows = state.customers;
  if (state.page === "expiring") rows = rows.filter(c => c.daysLeft <= 30 && c.daysLeft >= 0);
  if (state.page === "trials") rows = rows.filter(c => c.status === "試用中");
  if (state.page === "suspended") rows = rows.filter(c => ["停權", "已到期"].includes(c.status));
  rows = rows.filter(c => JSON.stringify(c).includes(state.query));
  return table(state.page === "entitlements" ? "產品使用權" : "客戶公司", ["客戶公司", "代碼", "產品", "到期日", "剩餘", "狀態", "負責人", "額度", "官網版型", "操作"], rows.map(c => [c.name, c.code, c.products, c.expiresAt, `${c.daysLeft} 天`, badge(c.status), c.owner, c.quota, c.template, rowActions("customer", c.id, true)]));
}

function usagePage() {
  return `<div class="grid two">
    ${panel("使用量與額度", state.customers.map(c => `<div class="quota"><div><b>${c.name}</b><span>${c.products}</span></div><meter min="0" max="100" value="${parseInt(c.quota)}"></meter>${badge(parseInt(c.quota) > 85 ? "即將到期" : "正常")}</div>`).join(""))}
    ${panel("額度調整", `<label>客戶公司<input value="綠沐生活有限公司"></label><label>增加發布額度<input value="20"></label><label>內部備註<textarea>客戶活動檔期需求，臨時提高額度。</textarea></label><button class="primary" data-action="toast" data-message="額度已模擬調整並留下紀錄">儲存調整</button>`)}
  </div>`;
}

function notificationsPage() {
  return `<div class="grid two">
    ${panel("通知規則", ["產品維護公告", "功能下架通知", "客戶即將到期提醒", "額度即將用完提醒", "HTML 檢查失敗通知"].map(x => `<div class="setting"><div><b>${x}</b><span>Email 與後台站內通知</span></div>${toggle(true, "toast", "通知規則已切換")}</div>`).join(""))}
    ${panel("撰寫通知", `<label>通知對象<input value="受影響客戶"></label><label>通知內容<textarea>您好，系統將於今日進行維護，期間部分功能可能暫停使用。</textarea></label><button class="primary" data-action="toast" data-message="已建立模擬通知，不會真實寄送">建立通知</button>`)}
  </div>`;
}

function logsPage(rows = state.logs, title = "操作紀錄") {
  return table(title, ["操作時間", "操作人", "操作內容", "影響對象"], rows.map(l => [l.time, l.user, l.action, l.target]));
}

function systemPage() {
  const title = { accounts: "內部帳號", roles: "角色與權限", settings: "系統設定" }[state.page];
  return `<div class="grid two">
    ${table(title, ["名稱", "角色", "狀態", "最近更新", "操作"], [["王小明", "系統管理員", badge("啟用"), "2026-08-13", `<button class="textBtn" data-action="toast" data-message="已開啟帳號設定">編輯</button>`], ["林怡君", "產品負責人", badge("啟用"), "2026-08-12", `<button class="textBtn" data-action="toast" data-message="已開啟帳號設定">編輯</button>`], ["測試帳號", "檢視者", badge("停權"), "2026-08-01", `<button class="textBtn" data-action="toast" data-message="已開啟帳號設定">編輯</button>`]])}
    ${panel("權限設定", `<label class="check"><input type="checkbox" checked>可管理產品總開關</label><label class="check"><input type="checkbox" checked>可發布官網版型</label><label class="check"><input type="checkbox">可匯出操作紀錄</label><button class="primary" data-action="toast" data-message="系統設定已儲存">儲存設定</button>`)}
  </div>`;
}

function productDetail() {
  const product = state.products.find(p => p.name === "官網方案");
  return panel("產品詳情", `<div class="tabs">${["產品概況", "功能管理", "使用客戶", "版本與發布", "異動紀錄", "官網版型管理"].map((t, i) => `<button class="${i === 0 ? "active" : ""}" data-action="detailTab" data-tab="${t}">${t}</button>`).join("")}</div><div id="detailBody" class="detail">${detailBody(product, "產品概況")}</div>`);
}

function detailBody(product, tab) {
  if (tab === "功能管理") return state.features.filter(f => f.product === product.name).map(f => `<div class="miniRow"><span>${f.name}</span>${badge(f.status)}${toggle(f.enabled, "toggleFeature", f.id)}</div>`).join("");
  if (tab === "使用客戶") return state.customers.filter(c => c.products.includes(product.name)).slice(0, 4).map(c => `<div class="miniRow"><span>${c.name}</span>${badge(c.status)}<button class="textBtn" data-action="edit" data-type="customer" data-id="${c.id}">查看</button></div>`).join("");
  if (tab === "官網版型管理") return state.templates.map(t => `<div class="miniRow"><span>${t.name}</span>${badge(t.status)}<button class="textBtn" data-action="toast" data-message="已開啟版型預覽">預覽</button></div>`).join("");
  return `${productName(product)}<p>${product.desc}</p>${badge(product.status)}<div class="emptyState"><span>▤</span><span>此頁籤呈現 ${tab} 的摘要、狀態、責任人與最近異動。</span></div>`;
}

function panel(title, body, action = "") {
  return `<section class="panel"><div class="panelHead"><h2>${title}</h2>${action ? `<button class="textBtn" data-page="products">${action}</button>` : ""}</div>${body}</section>`;
}

function table(title, columns, rows) {
  return panel(title, `<div class="tableWrap"><table><thead><tr>${columns.map(c => `<th>${c}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`);
}

function tabs(items) {
  return `<div class="tabs">${items.map(t => `<button class="${state.filter === t ? "active" : ""}" data-filter="${t}">${t}</button>`).join("")}</div>`;
}

function badge(value) {
  const tone = statusMeta[value]?.[0] || "muted";
  const symbol = { ok: "✓", warn: "!", bad: "×", info: "i", muted: "•" }[tone];
  return `<span class="badge ${tone}"><span>${symbol}</span>${value}</span>`;
}

function toggle(checked, action, id) {
  return `<button class="toggle ${checked ? "on" : ""}" data-action="${action}" data-id="${id}" aria-label="總開關"><span></span></button>`;
}

function productName(p) {
  return `<div class="nameCell"><div class="productIcon">${p.icon}</div><div><b>${p.name}</b><span>${p.owner}</span></div></div>`;
}

function rowActions(type, id, extend = false) {
  return `<div class="rowActions"><button class="iconBtn" title="查看" data-action="edit" data-type="${type}" data-id="${id}">⌕</button><button class="iconBtn" title="編輯" data-action="edit" data-type="${type}" data-id="${id}">✎</button>${extend ? `<button class="textBtn" data-action="extend" data-id="${id}">延長期限</button>` : ""}</div>`;
}

function filtered(items) {
  return items.filter(item => (state.filter === "全部" || Object.values(item).includes(state.filter) || item.product === state.filter || item.status === state.filter) && JSON.stringify(item).includes(state.query));
}

function modal() {
  if (!state.modal) return "";
  return `<div class="overlay">
    <section class="modal">
      <div class="modalHead"><div><p class="eyebrow">二次確認</p><h3>${state.modal.title}</h3></div><button class="iconBtn" data-action="closeModal">×</button></div>
      <div class="impactGrid"><div><b>${state.modal.customers}</b><span>影響客戶數</span></div><div><b>${state.modal.features}</b><span>影響功能數</span></div><div><b>${state.modal.target}</b><span>影響對象</span></div></div>
      <label>操作原因<textarea id="modalReason" placeholder="請填寫關閉或切換狀態原因"></textarea></label>
      <label>預計恢復時間<input id="modalRecovery" value="2026-08-13 18:00"></label>
      <label class="check"><input id="modalNotify" type="checkbox" checked>通知受影響客戶</label>
      <label class="check"><input id="modalConfirm" type="checkbox">我已確認影響範圍並留下操作紀錄</label>
      <div class="actions"><button class="ghost" data-action="closeModal">取消</button><button class="primary" data-action="confirmModal">確認執行</button></div>
    </section>
  </div>`;
}

function drawer() {
  if (!state.drawer) return "";
  const { type, item } = state.drawer;
  const fields = type === "customer"
    ? [["name", "客戶公司"], ["code", "客戶代碼"], ["contact", "聯絡人"], ["email", "Email"], ["products", "購買產品"], ["expiresAt", "到期日"], ["owner", "內部負責人"], ["note", "備註"]]
    : type === "product"
      ? [["name", "產品名稱"], ["code", "產品代碼"], ["desc", "產品說明"], ["version", "目前版本"], ["status", "產品狀態"], ["owner", "內部負責人"], ["notice", "維護公告"]]
      : [["name", "名稱"], ["code", "代碼"], ["version", "版本"], ["status", "狀態"], ["owner", "負責人"], ["desc", "說明"]];
  return `<div class="drawerWrap"><aside class="drawer">
    <div class="modalHead"><div><p class="eyebrow">${type === "customer" ? "客戶資料" : type === "product" ? "產品資料" : "資料設定"}</p><h3>${item.id?.startsWith("new") ? "新增" : "編輯"}${item.name ? `：${item.name}` : ""}</h3></div><button class="iconBtn" data-action="closeDrawer">×</button></div>
    <div class="formGrid">${fields.map(([key, label]) => `<label>${label}${key === "desc" || key === "notice" ? `<textarea data-field="${key}">${item[key] || ""}</textarea>` : `<input data-field="${key}" value="${escapeAttr(item[key] ?? "")}">`}</label>`).join("")}</div>
    <label class="check"><input data-field="enabled" type="checkbox" ${item.enabled ?? true ? "checked" : ""}>是否啟用</label>
    <div class="actions"><button class="ghost" data-action="closeDrawer">取消</button><button class="primary" data-action="saveDrawer">儲存</button></div>
  </aside></div>`;
}

function openConfirm(kind, id) {
  const item = kind === "product" ? state.products.find(x => x.id === id) : state.features.find(x => x.id === id);
  state.modal = {
    kind, id, target: item.name, customers: item.customers, features: kind === "product" ? item.featureCount : 1,
    title: `${item.enabled ? "關閉" : "啟用"}${kind === "product" ? "產品總開關" : "功能總開關"}`
  };
  render();
}

function confirmModal() {
  const reason = document.querySelector("#modalReason")?.value.trim();
  const ok = document.querySelector("#modalConfirm")?.checked;
  if (!reason || !ok) return showToast("請填寫原因並勾選二次確認");
  const { kind, id } = state.modal;
  if (kind === "product") {
    const p = state.products.find(x => x.id === id);
    p.enabled = !p.enabled;
    p.status = p.enabled ? "已上線" : "停止服務";
    addLog(`${p.enabled ? "啟用" : "關閉"}產品總開關：${reason}`, p.code);
  } else {
    const f = state.features.find(x => x.id === id);
    f.enabled = !f.enabled;
    f.status = f.enabled ? "已釋出" : "維護中";
    addLog(`${f.enabled ? "啟用" : "關閉"}功能總開關：${reason}`, f.code);
  }
  state.modal = null;
  showToast("狀態已更新，操作紀錄已建立");
}

function edit(type, id) {
  const source = { product: state.products, customer: state.customers, feature: state.features, template: state.templates }[type];
  state.drawer = { type, item: structuredClone(source.find(x => x.id === id)) };
  render();
}

function saveDrawer() {
  const draft = structuredClone(state.drawer.item);
  document.querySelectorAll("[data-field]").forEach(el => {
    draft[el.dataset.field] = el.type === "checkbox" ? el.checked : el.value;
  });
  const key = state.drawer.type === "customer" ? "customers" : state.drawer.type === "product" ? "products" : state.drawer.type === "template" ? "templates" : "features";
  if (draft.id?.startsWith("new")) draft.id = `${state.drawer.type}-${Date.now()}`;
  state[key] = state[key].some(x => x.id === draft.id) ? state[key].map(x => x.id === draft.id ? draft : x) : [draft, ...state[key]];
  addLog("儲存資料", draft.code || draft.name);
  state.drawer = null;
  showToast("資料已儲存");
}

function createItem() {
  const type = state.page === "customers" ? "customer" : state.page === "features" ? "feature" : state.page === "templates" ? "template" : "product";
  state.drawer = { type, item: { id: `new-${type}`, name: "", code: "", version: "v1.0.0", status: "開發中", enabled: true, owner: "王小明", desc: "" } };
  render();
}

function extendCustomer(id) {
  const c = state.customers.find(x => x.id === id);
  c.expiresAt = "2026-11-30";
  c.daysLeft = 109;
  c.status = "使用中";
  addLog("延長客戶使用期限", c.code);
  showToast(`${c.name} 已延長至 2026-11-30`);
}

function addLog(action, target) {
  state.logs.unshift({ id: `l-${Date.now()}`, time: "2026-08-13 14:20", user: "王小明", action, target });
}

function showToast(message) {
  state.toast = message;
  render();
  setTimeout(() => { state.toast = ""; render(); }, 2200);
}

function escapeAttr(value) {
  return String(value).replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;");
}

root.addEventListener("input", event => {
  if (event.target.id === "globalSearch") {
    state.query = event.target.value;
    render();
    document.querySelector("#globalSearch")?.focus();
  }
});

root.addEventListener("click", event => {
  const el = event.target.closest("button");
  if (!el) return;
  if (el.dataset.page) { state.page = el.dataset.page; state.filter = "全部"; render(); }
  if (el.dataset.filter) { state.filter = el.dataset.filter; render(); }
  if (el.dataset.action === "toggleProduct") openConfirm("product", el.dataset.id);
  if (el.dataset.action === "toggleFeature") openConfirm("feature", el.dataset.id);
  if (el.dataset.action === "closeModal") { state.modal = null; render(); }
  if (el.dataset.action === "confirmModal") confirmModal();
  if (el.dataset.action === "edit") edit(el.dataset.type, el.dataset.id);
  if (el.dataset.action === "closeDrawer") { state.drawer = null; render(); }
  if (el.dataset.action === "saveDrawer") saveDrawer();
  if (el.dataset.action === "create") createItem();
  if (el.dataset.action === "extend") extendCustomer(el.dataset.id);
  if (el.dataset.action === "toast") showToast(el.dataset.message || "操作已完成");
  if (el.dataset.action === "detailTab") {
    document.querySelectorAll(".tabs button[data-action='detailTab']").forEach(b => b.classList.toggle("active", b === el));
    document.querySelector("#detailBody").innerHTML = detailBody(state.products.find(p => p.name === "官網方案"), el.dataset.tab);
  }
});

render();
